#include<iostream>
using namespace std;
class RectangleArea
{
public:
	void SetDate(float L,float W);
	float ComputerArea();
	void OutPutArea();
private:
	float length,width,area;
}
void RectangleArea::SetDate(float L,float W)
{
	length=L;
	width=W;
}
float RectangleArea::ComputerArea()
{
	area=length*width;
	return area;
}
void RectangleArea::OutPutArea()
{
	cout<<"Area="<<area<<endl;
}
int main()
{
	RectangleArea Rectangle;
	Rectangle.SetDate(3,4);
	Rectangle.ComputerArea();
	Rectangle.OutPutArea();
	return 0;
}